# Bangla parts of speech predictor
 This system takes bangla sentences as input an predicts the parts of
 speech of every wrod in the given sentences using bi-gram viterbi algorithm
